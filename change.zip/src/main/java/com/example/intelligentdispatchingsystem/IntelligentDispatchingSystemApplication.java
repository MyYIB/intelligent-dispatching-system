package com.example.intelligentdispatchingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntelligentDispatchingSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(IntelligentDispatchingSystemApplication.class, args);
    }

}
